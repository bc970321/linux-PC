/*************************************************************************
	> File Name:    1.cpp
	> Author:       candy7 
	> Mail:         bc970321@163.com
	> Created Time: 2019年06月04日 星期二 14时00分48秒
 ************************************************************************/

#include<iostream>
using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    cout << a + b << endl;
    return 0;
}
